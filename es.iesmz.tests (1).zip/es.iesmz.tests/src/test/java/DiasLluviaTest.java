import junit.framework.TestCase;
import org.junit.Test;

public class DiasLluviaTest extends TestCase {

    @Test
    public void testRegistroDia() {
        DiasLluvia dias = new DiasLluvia();
        assertTrue(dias.registroDia(1, 1, true));
        assertTrue(dias.registroDia(31, 12, true));
        assertFalse(dias.registroDia(32, 12, true));
    }

    @Test
    public void testConsultarDia() {
        DiasLluvia dias = new DiasLluvia();
        dias.registroDia(1, 1, true);
        dias.registroDia(15, 7, false);
        assertTrue(dias.consultarDia(1, 1));
        assertFalse(dias.consultarDia(15, 7));
        assertFalse(dias.consultarDia(1, 2));
    }


    @Test
    public void testContarDiasLluviosos() {
        DiasLluvia dias = new DiasLluvia();
        dias.registroDia(1, 1, true);
        dias.registroDia(15, 7, false);
        dias.registroDia(2, 2, true);
        assertEquals(2, dias.contarDiasLluviosos());

    }

    @Test
    public void testTrimestreLuvioso() {
        DiasLluvia dias = new DiasLluvia();
        dias.registroDia(1, 1, true);
        dias.registroDia(2, 1, true);
        dias.registroDia(15, 2, true);
        dias.registroDia(20, 4, true);
        dias.registroDia(1, 6, true);
        dias.registroDia(31, 12, true);
        assertEquals(4, dias.trimestreLuvioso());
    }

    @Test
    public void testPrimerDiaLluvia() {
        DiasLluvia dias = new DiasLluvia();
        dias.registroDia(15, 7, true);
        dias.registroDia(1, 1, true);
        dias.registroDia(31, 12, true);
        assertEquals(1, dias.primerDiaLluvia());
        dias.registroDia(15, 1, true);
        assertEquals(1, dias.primerDiaLluvia());
        dias.registroDia(1, 2, true);
        assertEquals(1, dias.primerDiaLluvia());
        dias.registroDia(15, 2, true);
        assertEquals(1, dias.primerDiaLluvia());
        dias.registroDia(2, 2, true);
        assertEquals(2, dias.primerDiaLluvia());
    }
}