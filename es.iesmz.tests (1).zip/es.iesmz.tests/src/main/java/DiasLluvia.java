public class DiasLluvia {

    private boolean[][] diasLluvia;

    public DiasLluvia() {
        this.diasLluvia = new boolean[12][31];
    }

    public boolean registroDia(int dia, int mes, boolean lluvia) {
        if (dia < 1 || dia > 31 || mes < 1 || mes > 12) {
            return false;
        }
        this.diasLluvia[mes - 1][dia - 1] = lluvia;
        return true;
    }

    public boolean consultarDia(int dia, int mes) {
        if (dia < 1 || dia > 31 || mes < 1 || mes > 12) {
            return false;
        }
        return this.diasLluvia[mes - 1][dia - 1];
    }

    public int contarDiasLluviosos() {
        int totalDiasLluviosos = 0;
        for (boolean[] mes : this.diasLluvia) {
            for (boolean dia : mes) {
                if (dia) {
                    totalDiasLluviosos++;
                }
            }
        }
        return totalDiasLluviosos;
    }

    public int trimestreLuvioso() {
        int[] trimestres = new int[4];
        for (int mes = 0; mes < this.diasLluvia.length; mes++) {
            for (int dia = 0; dia < this.diasLluvia[mes].length; dia++) {
                if (this.diasLluvia[mes][dia]) {
                    if (mes < 3) {
                        trimestres[0]++;
                    } else if (mes < 6) {
                        trimestres[1]++;
                    } else if (mes < 9) {
                        trimestres[2]++;
                    } else {
                        trimestres[3]++;
                    }
                }
            }
        }
        int trimestreMasLluvioso = 1;
        int maxDiasLluviosos = trimestres[0];
        for (int i = 1; i < trimestres.length; i++) {
            if (trimestres[i] > maxDiasLluviosos) {
                trimestreMasLluvioso = i + 1;
                maxDiasLluviosos = trimestres[i];
            }
        }
        return trimestreMasLluvioso;
    }

    public int primerDiaLluvia(){

        for (int mes = 0; mes < this.diasLluvia.length; mes++) {
            for (int dia = 0; dia < this.diasLluvia[mes].length; dia++) {
                if (this.diasLluvia[mes][dia]) {
                    return mes * 31 + dia + 1;
                }
            }
        }
        return -1;
    }
}



